## Module <backend_theme_odoo12>

#### 24.07.2023
#### Version 16.0.1.0.0
##### ADD
- Initial Commit for Blueberry Backend Theme
